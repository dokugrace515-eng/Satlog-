package com.satlog.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF0B0D0C)
private val Card = Color(0xFF151916)
private val Gold = Color(0xFFD6B35A)
private val Green = Color(0xFF21A366)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { SatlogApp() } }
    }
}

data class Match(val league:String, val home:String, val away:String, val homeOdd:Double, val drawOdd:Double, val awayOdd:Double)
data class Pick(val label:String, val odd:Double)

@Composable fun SatlogApp() {
    var tab by remember { mutableIntStateOf(0) }
    var picks by remember { mutableStateOf(listOf<Pick>()) }
    var balance by remember { mutableDoubleStateOf(1000.0) }
    val matches = listOf(
        Match("Premier League", "Arsenal", "Chelsea", 1.85, 3.40, 4.10),
        Match("La Liga", "Barcelona", "Sevilla", 1.52, 4.20, 5.80),
        Match("Champions League", "Inter", "Bayern", 2.70, 3.25, 2.45)
    )
    Scaffold(containerColor = Bg, bottomBar = {
        NavigationBar(containerColor = Card) {
            listOf("Matches","Bet Slip","My Bets","Profile").forEachIndexed { i, s ->
                NavigationBarItem(selected=tab==i, onClick={tab=i}, icon={ Text(if(i==1 && picks.isNotEmpty()) "${picks.size}" else "•", color=if(tab==i) Gold else Color.Gray) }, label={Text(s)}, colors=NavigationBarItemDefaults.colors(indicatorColor=Color(0xFF263128), selectedTextColor=Gold, unselectedTextColor=Color.Gray))
            }
        }
    }) { pad ->
        Column(Modifier.fillMaxSize().padding(pad).padding(16.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween, verticalAlignment=Alignment.CenterVertically) {
                Column { Text("SATLOG", color=Gold, fontSize=28.sp, fontWeight=FontWeight.Black); Text("SPORTS • DEMO", color=Green, fontSize=11.sp) }
                Column(horizontalAlignment=Alignment.End) { Text("Demo wallet", color=Color.Gray, fontSize=11.sp); Text("GHS %.2f".format(balance), color=Color.White, fontWeight=FontWeight.Bold) }
            }
            Spacer(Modifier.height(20.dp))
            when(tab) {
                0 -> Matches(matches) { pick -> picks = picks + pick; tab = 1 }
                1 -> BetSlip(picks, balance, onRemove={picks=picks-it}, onPlace={stake -> if(stake>0 && stake<=balance && picks.isNotEmpty()){ balance-=stake; picks=emptyList(); tab=2 }})
                2 -> EmptyState("Demo bets", "Placed demo bets appear here. No real money is used.")
                else -> Profile(balance)
            }
        }
    }
}

@Composable fun Matches(matches:List<Match>, onPick:(Pick)->Unit) {
    Text("Featured matches", color=Color.White, fontSize=22.sp, fontWeight=FontWeight.Bold)
    Text("Tap an odd to add it to your bet slip.", color=Color.Gray)
    Spacer(Modifier.height(12.dp))
    matches.forEach { m ->
        Card(colors=CardDefaults.cardColors(containerColor=Card), modifier=Modifier.fillMaxWidth().padding(vertical=6.dp), shape=RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(16.dp)) {
                Text(m.league, color=Gold, fontSize=12.sp, fontWeight=FontWeight.Bold)
                Spacer(Modifier.height(8.dp)); Text("${m.home}  vs  ${m.away}", color=Color.White, fontSize=17.sp, fontWeight=FontWeight.SemiBold)
                Spacer(Modifier.height(12.dp)); Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                    Odd("1",m.homeOdd,Modifier.weight(1f)){onPick(Pick("${m.home} win",m.homeOdd))}
                    Odd("X",m.drawOdd,Modifier.weight(1f)){onPick(Pick("${m.home} vs ${m.away} draw",m.drawOdd))}
                    Odd("2",m.awayOdd,Modifier.weight(1f)){onPick(Pick("${m.away} win",m.awayOdd))}
                }
            }
        }
    }
}

@Composable fun Odd(label:String, odd:Double, modifier:Modifier, onClick:()->Unit) {
    Surface(color=Color(0xFF202720), shape=RoundedCornerShape(12.dp), modifier=modifier.clickable(onClick=onClick)) {
        Column(Modifier.padding(10.dp), horizontalAlignment=Alignment.CenterHorizontally) { Text(label,color=Color.Gray,fontSize=11.sp); Text("%.2f".format(odd),color=Green,fontWeight=FontWeight.Bold) }
    }
}

@Composable fun BetSlip(picks:List<Pick>, balance:Double, onRemove:(Pick)->Unit, onPlace:(Double)->Unit) {
    var stakeText by remember { mutableStateOf("10") }
    val stake=stakeText.toDoubleOrNull()?:0.0; val total=picks.fold(1.0){a,p->a*p.odd}
    Text("Bet Slip", color=Color.White, fontSize=22.sp, fontWeight=FontWeight.Bold); Spacer(Modifier.height(10.dp))
    if(picks.isEmpty()) { EmptyState("Your slip is empty","Choose an odd from Matches to start a demo bet."); return }
    picks.forEach { p -> Row(Modifier.fillMaxWidth().padding(vertical=7.dp), horizontalArrangement=Arrangement.SpaceBetween) { Column(Modifier.weight(1f)){Text(p.label,color=Color.White);Text("Odd %.2f".format(p.odd),color=Green)}; Text("Remove",color=Gold,modifier=Modifier.clickable{onRemove(p)}) } }
    Spacer(Modifier.height(10.dp)); OutlinedTextField(value=stakeText,onValueChange={stakeText=it.filter{c->c.isDigit()||c=='.'}},label={Text("Demo stake (GHS)")},modifier=Modifier.fillMaxWidth(),colors=OutlinedTextFieldDefaults.colors(focusedBorderColor=Gold,focusedLabelColor=Gold,focusedTextColor=Color.White,unfocusedTextColor=Color.White))
    Spacer(Modifier.height(10.dp)); Text("Total odds: %.2f   Potential demo return: GHS %.2f".format(total,stake*total),color=Color.White)
    Spacer(Modifier.height(12.dp)); Button(onClick={onPlace(stake)},enabled=stake>0&&stake<=balance,modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=Green)){Text("PLACE DEMO BET",fontWeight=FontWeight.Bold)}
}

@Composable fun Profile(balance:Double) { Text("Profile",color=Color.White,fontSize=22.sp,fontWeight=FontWeight.Bold); Spacer(Modifier.height(14.dp)); Card(colors=CardDefaults.cardColors(containerColor=Card),modifier=Modifier.fillMaxWidth()){Column(Modifier.padding(18.dp)){Text("Satlog Demo Player",color=Gold,fontWeight=FontWeight.Bold);Text("Virtual balance: GHS %.2f".format(balance),color=Color.White);Spacer(Modifier.height(10.dp));Text("Prototype mode • 18+ concept • No deposits or withdrawals",color=Color.Gray)}} }
@Composable fun EmptyState(title:String, body:String){Box(Modifier.fillMaxWidth().padding(top=70.dp),contentAlignment=Alignment.Center){Column(horizontalAlignment=Alignment.CenterHorizontally){Text(title,color=Gold,fontSize=20.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(6.dp));Text(body,color=Color.Gray)}}}
